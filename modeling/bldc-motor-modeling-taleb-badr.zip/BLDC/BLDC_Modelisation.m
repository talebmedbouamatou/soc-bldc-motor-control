% --- Paramètres moteur BLDC ---

R   = 0.05;        % Ohm
L   = 5e-6;        % H 
Ke  = 0.01;        % V/(rad/s)
Kt  = 0.01;        % N.m/A
J   = 5e-6;        % kg.m^2  ou 1e-6 
B   = 1e-6;        % N.m.s
p   = 7;           % nombre de paire de pôles // Souvent 7
Tl  = 0;           % couple de charge